//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruitsArray = ["Kiwi", "Onion", "Tomato", "Apple", "banana"];

//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert (fruitsArray [2]);