﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION


//################## CREATE YOUR FUNCTION
function coursePopup(courseCode, courseName) 
{
    alert("The course code " + courseCode + " is " + courseName + ".");
}


//################## TEST YOUR FUNCTION

coursePopup("HTTP5121", "Web Design");
coursePopup("HTTP5122", "Front-End Web Development 1");
coursePopup("IXD5106", "Interaction Design");